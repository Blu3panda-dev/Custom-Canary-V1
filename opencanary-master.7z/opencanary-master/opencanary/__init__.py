import os

__version__ = "0.9.5"

STDPATH = os.pathsep.join(["/usr/bin", "/bin", "/usr/sbin", "/sbin"])
