MSSQL Server
================

Inside ~/.opencanary.conf:

.. code-block:: json

   {
       "mssql.enabled": true,
       "mssql.port": 1433,
       "mssql.version": "2012",
       "rdp.enabled": true,
       "rdp.port", 3389,
       // [..] # logging configuration
   }
